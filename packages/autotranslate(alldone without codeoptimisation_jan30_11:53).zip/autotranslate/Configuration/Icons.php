<?php

return [
    'autotranslate-main-icon' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:autotranslate/Resources/Public/Icons/module-icon.svg',
    ],
];