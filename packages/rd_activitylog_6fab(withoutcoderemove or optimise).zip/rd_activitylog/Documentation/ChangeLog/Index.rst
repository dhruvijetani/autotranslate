.. include:: ../Includes.txt

.. _changelog:

==========
Change log
==========

Version 1.0.0
-------------

Use this chapter to inform users of your extension about changes you made with each released version.
