<?php

declare(strict_types=1);

namespace RD\Autotranslate\Domain\Model;


/**
 * This file is part of the "Auto Translate" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2026 
 */

/**
 * Autotranslate
 */
class Autotranslate extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * pageUid
     *
     * @var int
     */
    protected $pageUid = null;

    /**
     * sourceLang
     *
     * @var int
     */
    protected $sourceLang = null;

    /**
     * targetLang
     *
     * @var int
     */
    protected $targetLang = null;

    /**
     * recordsTranslated
     *
     * @var int
     */
    protected $recordsTranslated = null;

    /**
     * status
     *
     * @var string
     */
    protected $status = null;

    /**
     * message
     *
     * @var string
     */
    protected $message = null;

    /**
     * Returns the pageUid
     *
     * @return int
     */
    public function getPageUid()
    {
        return $this->pageUid;
    }

    /**
     * Sets the pageUid
     *
     * @param int $pageUid
     * @return void
     */
    public function setPageUid(int $pageUid)
    {
        $this->pageUid = $pageUid;
    }

    /**
     * Returns the sourceLang
     *
     * @return int
     */
    public function getSourceLang()
    {
        return $this->sourceLang;
    }

    /**
     * Sets the sourceLang
     *
     * @param int $sourceLang
     * @return void
     */
    public function setSourceLang(int $sourceLang)
    {
        $this->sourceLang = $sourceLang;
    }

    /**
     * Returns the targetLang
     *
     * @return int
     */
    public function getTargetLang()
    {
        return $this->targetLang;
    }

    /**
     * Sets the targetLang
     *
     * @param int $targetLang
     * @return void
     */
    public function setTargetLang(int $targetLang)
    {
        $this->targetLang = $targetLang;
    }

    /**
     * Returns the recordsTranslated
     *
     * @return int
     */
    public function getRecordsTranslated()
    {
        return $this->recordsTranslated;
    }

    /**
     * Sets the recordsTranslated
     *
     * @param int $recordsTranslated
     * @return void
     */
    public function setRecordsTranslated(int $recordsTranslated)
    {
        $this->recordsTranslated = $recordsTranslated;
    }

    /**
     * Returns the status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Sets the status
     *
     * @param string $status
     * @return void
     */
    public function setStatus(string $status)
    {
        $this->status = $status;
    }

    /**
     * Returns the message
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Sets the message
     *
     * @param string $message
     * @return void
     */
    public function setMessage(string $message)
    {
        $this->message = $message;
    }
}
