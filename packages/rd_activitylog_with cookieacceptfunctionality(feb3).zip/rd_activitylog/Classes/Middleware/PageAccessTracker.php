<?php
namespace RemoteDevs\RdActivitylog\Middleware;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class PageAccessTracker implements MiddlewareInterface {
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface {
        $response = $handler->handle($request);
        $pageId = $request->getAttribute('routing')?->getPageId() ?? 0;

        if ($pageId > 0) {
            if (session_status() === PHP_SESSION_NONE) { session_start(); }

            // Only log if the page is different from the last one (prevents refresh count)
            if (!isset($_SESSION['rd_last_pid']) || $_SESSION['rd_last_pid'] !== $pageId) {
                $os = $this->detectOS($_SERVER['HTTP_USER_AGENT'] ?? '');
                
                GeneralUtility::makeInstance(ConnectionPool::class)
                    ->getConnectionForTable('tx_rdactivitylog_domain_model_log')
                    ->insert('tx_rdactivitylog_domain_model_log', [
                        'page_uid' => (int)$pageId,
                        'action_type' => 'view',
                        'user_os' => $os,
                        'tstamp' => time()
                    ]);

                $_SESSION['rd_last_pid'] = $pageId;
            }
        }
        return $response;
    }

    private function detectOS(string $ua): string {
        if (preg_match('/iphone|ipad|ipod/i', $ua)) return 'iOS';
        if (preg_match('/android/i', $ua)) return 'Android';
        if (preg_match('/linux/i', $ua)) return 'Linux';
        if (preg_match('/macintosh|mac os x/i', $ua)) return 'Mac OS';
        if (preg_match('/windows|win32/i', $ua)) return 'Windows';
        return 'Unknown';
    }
}

