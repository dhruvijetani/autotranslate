<?php

declare(strict_types=1);

namespace RemoteDevs\RdActivitylog\Controller;


use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use Psr\Http\Message\ResponseInterface;

/**
 * This file is part of the "RD ActivityLog" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2026 
 */

/**
 * LogController
 */
class LogController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * logRepository
     *
     * @var \RD\RdActivitylog\Domain\Repository\LogRepository
     */
    protected $logRepository = null;

    /**
     * @param \RD\RdActivitylog\Domain\Repository\LogRepository $logRepository
     */
    public function injectLogRepository(\RemoteDevs\RdActivitylog\Domain\Repository\LogRepository $logRepository)
    {
        $this->logRepository = $logRepository;
    }

    // /**
    //  * action index
    //  *
    //  * @return \Psr\Http\Message\ResponseInterface
    //  */
    // public function indexAction(): \Psr\Http\Message\ResponseInterface
    // {
    //     return $this->htmlResponse();
    // }

    //     public function indexAction(): ResponseInterface {
    //     $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
    //         ->getQueryBuilderForTable('tx_rdactivitylog_domain_model_log');

    //     // Fetch all logs to process breakdown
    //     $rows = $queryBuilder->select('page_uid', 'user_os')
    //         ->from('tx_rdactivitylog_domain_model_log')
    //         ->executeQuery()->fetchAllAssociative();

    //     $stats = [];
    //     foreach ($rows as $row) {
    //         $pid = $row['page_uid'];
    //         $os = $row['user_os'];
    //         if (!isset($stats[$pid])) {
    //             $stats[$pid] = ['total' => 0, 'os' => []];
    //         }
    //         $stats[$pid]['total']++;
    //         $stats[$pid]['os'][$os] = ($stats[$pid]['os'][$os] ?? 0) + 1;
    //     }

    //     $this->view->assign('pageStats', $stats);
    //     return $this->htmlResponse();
    // }

    // public function indexAction(): \Psr\Http\Message\ResponseInterface {
    //     $queryBuilder = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Database\ConnectionPool::class)
    //         ->getQueryBuilderForTable('tx_rdactivitylog_domain_model_log');

    //     $rows = $queryBuilder->select('*')
    //         ->from('tx_rdactivitylog_domain_model_log')
    //         ->orderBy('tstamp', 'DESC')
    //         ->executeQuery()->fetchAllAssociative();

    //     $pageStats = [];
    //     $backendActivity = [];

    //     foreach ($rows as $row) {
    //         if ($row['action_type'] === 'view') {
    //             $pid = $row['page_uid'];
    //             $os = $row['user_os'];
    //             $pageStats[$pid]['total'] = ($pageStats[$pid]['total'] ?? 0) + 1;
    //             $pageStats[$pid]['os'][$os] = ($pageStats[$pid]['os'][$os] ?? 0) + 1;
    //         } else {
    //             // Split the string here in PHP
    //             $parts = explode('|', $row['user_os']);
    //             $row['display_user'] = trim($parts[0] ?? 'Unknown User');
    //             $row['display_item'] = trim($parts[1] ?? 'Unknown Item');
    //             $backendActivity[] = $row;
    //         }
    //     }

    //     $this->view->assignMultiple([
    //         'pageStats' => $pageStats,
    //         'backendActivity' => $backendActivity
    //     ]);

    //     return $this->htmlResponse();
    // }

    // /**
    //  * Delete all logs
    //  */
    // public function flushAction(): ResponseInterface {
    //     GeneralUtility::makeInstance(ConnectionPool::class)
    //         ->getConnectionForTable('tx_rdactivitylog_domain_model_log')
    //         ->truncate('tx_rdactivitylog_domain_model_log');

    //     return $this->redirect('index');
    // }



    public function indexAction(): ResponseInterface {
            $dbPool = GeneralUtility::makeInstance(ConnectionPool::class);

            // 1. Fetch Page Views (Frontend) from the ORIGINAL table
            $viewQuery = $dbPool->getQueryBuilderForTable('tx_rdactivitylog_domain_model_log');
            $viewRows = $viewQuery->select('*')
                ->from('tx_rdactivitylog_domain_model_log')
                ->where($viewQuery->expr()->eq('action_type', $viewQuery->createNamedParameter('view')))
                ->executeQuery()
                ->fetchAllAssociative();

            $pageStats = [];
            foreach ($viewRows as $row) {
                $pid = $row['page_uid'];
                $os = $row['user_os'];
                $pageStats[$pid]['total'] = ($pageStats[$pid]['total'] ?? 0) + 1;
                $pageStats[$pid]['os'][$os] = ($pageStats[$pid]['os'][$os] ?? 0) + 1;
            }

            // 2. Fetch Backend Activity from the NEW table
            $activityQuery = $dbPool->getQueryBuilderForTable('tx_rdactivitylog_domain_model_backendlog');
            $activityRows = $activityQuery->select('*')
                ->from('tx_rdactivitylog_domain_model_backendlog')
                ->orderBy('tstamp', 'DESC')
                ->executeQuery()
                ->fetchAllAssociative();

            $backendActivity = [];
            foreach ($activityRows as $row) {
                $parts = explode('|', $row['user_os']);
                $row['display_user'] = trim($parts[0] ?? 'Unknown');
                $row['display_item'] = trim($parts[1] ?? 'Unknown');
                $backendActivity[] = $row;
            }

            $this->view->assignMultiple([
                'pageStats' => $pageStats,
                'backendActivity' => $backendActivity
            ]);

            return $this->htmlResponse();
        }

    public function flushAction(): ResponseInterface {
        // Only clears the backend activity table
        GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('tx_rdactivitylog_domain_model_backendlog')
            ->truncate('tx_rdactivitylog_domain_model_backendlog');

        return $this->redirect('index');
    }
}
