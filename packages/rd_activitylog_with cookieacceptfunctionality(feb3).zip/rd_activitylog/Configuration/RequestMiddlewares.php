<?php
return [
    'frontend' => [
        'remotedevs/rd-activitylog/tracker' => [
            'target' => \RemoteDevs\RdActivitylog\Middleware\PageAccessTracker::class,
            'after' => ['typo3/cms-frontend/prepare-tsfe-rendering'],
        ],
    ],
];