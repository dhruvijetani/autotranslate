document.addEventListener('DOMContentLoaded', function () {
    const btnInsights = document.getElementById('btn-insights');
    const btnBackend = document.getElementById('btn-backend');
    const tabInsights = document.getElementById('tab-insights');
    const tabBackend = document.getElementById('tab-backend');

    function switchTab(type) {
        if (type === 'insights') {
            tabInsights.style.display = 'block';
            tabBackend.style.display = 'none';
            btnInsights.style.background = '#007bff';
            btnBackend.style.background = '#6c757d';
        } else {
            tabInsights.style.display = 'none';
            tabBackend.style.display = 'block';
            btnInsights.style.background = '#6c757d';
            btnBackend.style.background = '#007bff';
        }
    }

    if (btnInsights) {
        btnInsights.addEventListener('click', function() {
            switchTab('insights');
        });
    }

    if (btnBackend) {
        btnBackend.addEventListener('click', function() {
            switchTab('backend');
        });
    }
});



// popup js

document.addEventListener('DOMContentLoaded', function() {
    const flushBtn = document.getElementById('flush-log-btn');
    const modalOverlay = document.getElementById('custom-alert-overlay');
    const cancelBtn = document.getElementById('alert-cancel');
    const confirmBtn = document.getElementById('alert-confirm');

    if (flushBtn && modalOverlay) {
        // 1. When clicking the "Clear All" link
        flushBtn.addEventListener('click', function(event) {
            event.preventDefault(); // Stop the link from redirecting
            modalOverlay.style.display = 'flex'; // Show our HTML popup
        });

        // 2. When clicking "Cancel"
        cancelBtn.addEventListener('click', function() {
            modalOverlay.style.display = 'none'; // Hide the popup
        });

        // 3. When clicking "Yes, Clear All"
        confirmBtn.addEventListener('click', function() {
            const targetUrl = flushBtn.getAttribute('href');
            window.location.href = targetUrl; // Now perform the redirect
        });
    }
});





// cookie


document.addEventListener('DOMContentLoaded', function() {
    const banner = document.getElementById('cookie-consent-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');

    // Check if user already gave consent
    if (!getCookie('rd_cookie_consent')) {
        banner.style.display = 'block';
    }

    acceptBtn.addEventListener('click', function() {
        setCookie('rd_cookie_consent', 'accepted', 30); // 30 divas mate set thase
        banner.style.display = 'none';
        location.reload(); // Page reload karo jethi middleware run thai shake
    });

    declineBtn.addEventListener('click', function() {
        setCookie('rd_cookie_consent', 'declined', 30);
        banner.style.display = 'none';
    });

    function setCookie(name, value, days) {
        const d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = name + "=" + value + ";expires=" + d.toUTCString() + ";path=/";
    }

    function getCookie(name) {
        let nameEQ = name + "=";
        let ca = document.cookie.split(';');
        for(let i=0;i < ca.length;i++) {
            let c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    }
});
