.. include:: ../Includes.txt

.. _installation:

============
Installation
============

- How is the extension installed?
- Are there any dependencies that need to be resolved?

References to general TYPO3 documentation are possible,
for example the :ref:`t3install:start`.
