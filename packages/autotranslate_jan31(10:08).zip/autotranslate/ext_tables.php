<?php
defined('TYPO3') || die();

(static function() {
    // \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_autotranslate_domain_model_autotranslate', 'EXT:autotranslate/Resources/Private/Language/locallang_csh_tx_autotranslate_domain_model_autotranslate.xlf');
    // \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_autotranslate_domain_model_autotranslate');
})();
