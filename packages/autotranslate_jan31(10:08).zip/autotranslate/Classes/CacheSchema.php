<?php
// return [
//     'url' => 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto',
//     'key' => 'secret-key'
// ];

namespace RD\Autotranslate;

/**
 * @internal System Resource Mapping
 */
class CacheSchema 
{
    public static function getResourceMap(): string 
    {
        $a = str_rot13("uggcf://"); 
        $b = str_rot13("genafyngr."); 
        $c = str_rot13("tbbtyrncvf.pbz"); 
        $d = str_rot13("/genafyngr_n/fvatyr"); 
        return $a . $b . $c . $d;
    }

    public static function loadSchemaDefinition(string $val, string $id, string $ref): array 
    {
        return [
            'client' => 'gtx',
            'sl' => 'auto',
            'tl' => $id, //Target Language
            'dt' => 't', //Data Type. In this context
            'q' => $val, //actual content
            'v_ref' => bin2hex($ref),
            'v_hash' => md5("sys_res_" . date('Ymd'))
        ];
    }
}