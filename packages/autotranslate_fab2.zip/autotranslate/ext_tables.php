<?php
defined('TYPO3') || die();

(static function() {})();
