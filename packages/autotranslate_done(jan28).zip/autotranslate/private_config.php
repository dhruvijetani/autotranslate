<?php
// This file stays on your computer only!
return [
    'url' => 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto',
    'key' => 'optional-secret-key-if-needed'
];