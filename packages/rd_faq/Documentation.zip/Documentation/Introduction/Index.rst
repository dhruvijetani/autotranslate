.. _introduction:

Introduction
============

This chapter provides an overview of the features and functionalities of the TYPO3 CMS extension "*rd_faq*". 

.. toctree::
   :maxdepth: 5
   :titlesonly:

   About/Index
   Support/Index
