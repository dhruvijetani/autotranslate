<?php

return [
    'rdfaq-plugin-faqlist' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:rd_faq/Resources/Public/Icons/faq.svg'
    ],
];
