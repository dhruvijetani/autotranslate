<?php
defined('TYPO3') || die();

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('rd_faq', 'Configuration/TypoScript', 'Rd FAQs');
