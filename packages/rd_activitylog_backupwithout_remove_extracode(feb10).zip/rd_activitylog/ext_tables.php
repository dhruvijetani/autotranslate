<?php
defined('TYPO3') || die();

(static function() {
    // \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_rdactivitylog_domain_model_log', 'EXT:rd_activitylog/Resources/Private/Language/locallang_csh_tx_rdactivitylog_domain_model_log.xlf');
    // \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_rdactivitylog_domain_model_log');
})();
